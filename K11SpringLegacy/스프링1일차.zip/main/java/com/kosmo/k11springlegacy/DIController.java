package com.kosmo.k11springlegacy;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import di.Calculator;

@Controller
public class DIController {
	 
	@RequestMapping("/di/myCalculator")
	public String myCal(Model model) {
	 
		String configLocation = "classpath:DIAppCtxCalculator.xml";
				 
		AbstractApplicationContext ctx = 
			new GenericXmlApplicationContext(configLocation);
				 
		Calculator calculator = ctx.getBean("calculator", Calculator.class);
				 
		model.addAttribute("addResult", calculator.adder());
		model.addAttribute("subResult", calculator.sub());
		model.addAttribute("mulResult", calculator.multi());
		model.addAttribute("divResult", calculator.divide());
		
		return "04DI/myCalculator";
	}
	 
}
