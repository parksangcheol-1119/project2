package env;

public class UserConnection {
	//멤버변수
	private String mainUserId;
	private String mainUserPw;
	private String subUserId;
	private String subUserPw;
	
	//getter/setter
	public String getMainUserId() {
		return mainUserId;
	}
	public void setMainUserId(String mainUserId) {
		this.mainUserId = mainUserId;
	}
	public String getMainUserPw() {
		return mainUserPw;
	}
	public void setMainUserPw(String mainUserPw) {
		this.mainUserPw = mainUserPw;
	}
	public String getSubUserId() {
		return subUserId;
	}
	public void setSubUserId(String subUserId) {
		this.subUserId = subUserId;
	}
	public String getSubUserPw() {
		return subUserPw;
	}
	public void setSubUserPw(String subUserPw) {
		this.subUserPw = subUserPw;
	}
}

