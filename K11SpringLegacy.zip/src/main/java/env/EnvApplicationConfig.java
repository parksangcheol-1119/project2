package env;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
public class EnvApplicationConfig {

	@Value("${board1.user}")
	private String board_user;//계정아이디

	@Value("${board1.pass}")
	private String board_pass;//계정아이디
	
	@Value("${board2.driver}")
	private String board_driver;//계정아이디
	
	@Value("${board2.url}")
	private String board_url;//계정아이디
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer
	properties() {
		
		PropertySourcesPlaceholderConfigurer config =
				new PropertySourcesPlaceholderConfigurer();
		
		Resource[] locations = new Resource[2];
		
		locations[0] = new ClassPathResource("EnvBoard1.properties");
		locations[1] = new ClassPathResource("EnvBoard2.properties");
	
		config.setLocations(locations);
		
		return config;
	
	}
	
	@Bean
	public BoardConnection boardConfig() {
		
		BoardConnection bconn = new BoardConnection();
		
		bconn.setUser(board_user);
		bconn.setPass(board_pass);
		bconn.setDriver(board_driver);
		bconn.setUrl(board_url);
		
		return bconn;
	}
}
